PCMT Spectra Frontend - shared 1v1 playercams + freecam overlay

New route:
  /overlay-freecam

Behavior on /overlay-freecam:
  - Uses the same MatchOverlayComponent as /overlay.
  - Suppresses observed/POV highlighting on all PlayerCombatCardComponent instances, including 1v1 cards.
  - Normal observed-player playercams remain hidden.
  - The persistent playercam iframe pool remains mounted and connected.
  - During a 1v1, the two survivor feeds from that same pool move into the 1v1 camera positions.
  - No second VDO.Ninja/WebRTC viewer is created by the 1v1 component.

Replace these repository files with the files in this package:
  src/app/app-routing.module.ts
  src/app/components/combat/player-combat-card/player-combat-card.component.ts
  src/app/components/combat/playercams/playercams.component.ts
  src/app/components/combat/playercams/playercams.component.html
  src/app/components/combat/playercams/playercams.component.css
  src/app/components/combat/1v1/1v1.component.ts
  src/app/components/combat/1v1/1v1.component.css

Base repository/branch inspected:
  ianmdesign/PCMT-Spectra-Frontend-Nobii
  master
