import { Component, inject, OnDestroy, OnInit } from "@angular/core";
import { AgentSelectOverlayComponent } from "../agent-select-overlay/agent-select-overlay.component";
import { DataModelService } from "../../services/dataModel.service";
import { IMatchData } from "../../services/Types";

@Component({
  selector: "app-testing-agent-select",
  imports: [AgentSelectOverlayComponent],
  templateUrl: "./testing-agent-select.component.html",
  styleUrl: "./testing-agent-select.component.css",
})
export class TestingAgentSelectComponent implements OnInit, OnDestroy {
  readonly dataModel = inject(DataModelService);
  private agentSelectTimer?: number;

  ngOnInit(): void {
    const match: IMatchData = {
      groupCode: "A",
      isRanked: false,
      isRunning: true,
      roundNumber: 0,
      roundPhase: "LOBBY",
      spikeState: { planted: false, defused: false, detonated: false },
      map: "Ascent",
      switchRound: 12,
      firstOtRound: 25,
      showAliveKDA: true,
      attackersWon: false,
      agentSelectStartTime: 0,
      tools: {
        seriesInfo: {
          needed: 3,
          wonLeft: 2,
          wonRight: 2,
          mapInfo: [
            {
              type: "past",
              map: "Fracture",
              left: {
                score: 13,
                logo: "assets/misc/icon.webp",
              },
              right: {
                score: 9,
                logo: "assets/misc/icon.webp",
              },
            },
            {
              type: "present",
              logo: "assets/misc/icon.webp",
            },
            {
              type: "future",
              map: "Haven",
              logo: "assets/misc/icon.webp",
            },
          ],
        },
        seedingInfo: {
          left: "Group A",
          right: "Group B",
        },
        tournamentInfo: {
          name: "",
          logoUrl: "assets/misc/logo.webp",
          backdropUrl: "",
        },
        timeoutDuration: 60,
        timeoutCounter: {
          max: 2,
          left: 2,
          right: 2,
        },
        timeoutCancellationGracePeriod: 10,
        sponsorInfo: {
          enabled: true,
          duration: 5000,
          sponsors: ["assets/misc/logo.webp", "assets/misc/icon.webp"],
        },
        watermarkInfo: {
          customText: "",
          customTextEnabled: false,
          spectraWatermark: true,
        },
        playercamsInfo: {
          enable: false,
        },
        nameOverrides: {
          overrides: [],
        },
        roundWinBox: {
          type: "tournamentInfo",
          sponsors: [],
        },
        agentSelectActive: false,
      },
      toastInfo: {
        active: false,
        duration: 10000,
        title: "",
        message: "",
        selectedTeam: "none",
        eventLogoEnabled: true,
      },
      timeoutState: {
        techPause: false,
        leftTeam: false,
        rightTeam: false,
        timeRemaining: 0,
      },
      teams: [
        {
          players: [
            {
              name: "Test",
              fullName: "Test#ABC",
              playerId: 0,
              isAlive: true,
              agentInternal: "Vampire",
              locked: false,
              isObserved: false,
              armorName: "",
              money: 0,
              moneySpent: 0,
              highestWeapon: "",
              isCaptain: false,
              currUltPoints: 0,
              maxUltPoints: 7,
              ultReady: false,
              hasSpike: false,
              scoreboardAvailable: true,
              auxiliaryAvailable: {
                health: true,
                abilities: true,
                scoreboard: true,
              },
              kills: 0,
              deaths: 0,
              assists: 0,
              killsThisRound: 0,
              deathsThisRound: 0,
              killedPlayerNames: [],
              health: 100,
              abilities: {
                grenade: 1,
                ability1: 1,
                ability2: 0,
              },
              iconNameSuffix: "",
            },
            {
              name: "Test",
              fullName: "Testg#ABC",
              playerId: 0,
              isAlive: true,
              agentInternal: "Smonk",
              locked: false,
              isObserved: false,
              armorName: "Heavy",
              money: 2100,
              moneySpent: 2900,
              highestWeapon: "Vandal",
              isCaptain: false,
              currUltPoints: 2,
              maxUltPoints: 7,
              ultReady: false,
              hasSpike: false,
              scoreboardAvailable: true,
              auxiliaryAvailable: {
                health: true,
                abilities: true,
                scoreboard: true,
              },
              kills: 0,
              deaths: 0,
              assists: 0,
              killsThisRound: 0,
              deathsThisRound: 0,
              killedPlayerNames: [],
              health: 100,
              abilities: {
                grenade: 1,
                ability1: 1,
                ability2: 0,
              },
              iconNameSuffix: "",
            },
            {
              name: "Test",
              fullName: "Testg#ABC",
              playerId: 0,
              isAlive: true,
              agentInternal: "Paprika",
              locked: false,
              isObserved: false,
              armorName: "Heavy",
              money: 2100,
              moneySpent: 2900,
              highestWeapon: "Vandal",
              isCaptain: false,
              currUltPoints: 2,
              maxUltPoints: 7,
              ultReady: false,
              hasSpike: false,
              scoreboardAvailable: true,
              auxiliaryAvailable: {
                health: true,
                abilities: true,
                scoreboard: true,
              },
              kills: 0,
              deaths: 0,
              assists: 0,
              killsThisRound: 0,
              deathsThisRound: 0,
              killedPlayerNames: [],
              health: 100,
              abilities: {
                grenade: 1,
                ability1: 1,
                ability2: 0,
              },
              iconNameSuffix: "",
            },
            {
              name: "Test",
              fullName: "Testg#ABC",
              playerId: 0,
              isAlive: true,
              agentInternal: "Wushu",
              locked: false,
              isObserved: false,
              armorName: "Heavy",
              money: 2100,
              moneySpent: 2900,
              highestWeapon: "Vandal",
              isCaptain: false,
              currUltPoints: 2,
              maxUltPoints: 7,
              ultReady: false,
              hasSpike: false,
              scoreboardAvailable: true,
              auxiliaryAvailable: {
                health: true,
                abilities: true,
                scoreboard: true,
              },
              kills: 0,
              deaths: 0,
              assists: 0,
              killsThisRound: 0,
              deathsThisRound: 0,
              killedPlayerNames: [],
              health: 100,
              abilities: {
                grenade: 1,
                ability1: 1,
                ability2: 0,
              },
              iconNameSuffix: "",
            },
            {
              name: "Test",
              fullName: "Testg#ABC",
              playerId: 0,
              isAlive: true,
              agentInternal: "Wushu",
              locked: false,
              isObserved: false,
              armorName: "Heavy",
              money: 2100,
              moneySpent: 2900,
              highestWeapon: "Vandal",
              isCaptain: false,
              currUltPoints: 2,
              maxUltPoints: 7,
              ultReady: false,
              hasSpike: false,
              scoreboardAvailable: true,
              auxiliaryAvailable: {
                health: true,
                abilities: true,
                scoreboard: true,
              },
              kills: 0,
              deaths: 0,
              assists: 0,
              killsThisRound: 0,
              deathsThisRound: 0,
              killedPlayerNames: [],
              health: 100,
              abilities: {
                grenade: 1,
                ability1: 1,
                ability2: 0,
              },
              iconNameSuffix: "",
            },
          ],
          teamName: "The Naturals",
          teamUrl: "assets/misc/icon.webp",
          teamTricode: "INT",
          spentThisRound: 1000,
          isAttacking: false,
          roundsWon: 5,
          roundRecord: [
            { type: "detonated", wasAttack: true, round: 1 },
            { type: "lost", wasAttack: true, round: 2 },
            { type: "kills", wasAttack: true, round: 3 },
            { type: "timeout", wasAttack: true, round: 4 },
            { type: "lost", wasAttack: true, round: 5 },
            { type: "kills", wasAttack: true, round: 6 },
            { type: "lost", wasAttack: true, round: 7 },
            { type: "defused", wasAttack: true, round: 8 },
            { type: "lost", wasAttack: true, round: 9 },
            { type: "lost", wasAttack: true, round: 10 },
            { type: "detonated", wasAttack: true, round: 11 },
            { type: "lost", wasAttack: true, round: 12 },
            { type: "kills", wasAttack: false, round: 13 },
            { type: "timeout", wasAttack: false, round: 14 },
            { type: "lost", wasAttack: false, round: 15 },
            { type: "kills", wasAttack: false, round: 16 },
            { type: "lost", wasAttack: false, round: 17 },
            { type: "defused", wasAttack: false, round: 18 },
            { type: "lost", wasAttack: false, round: 19 },
            { type: "lost", wasAttack: false, round: 20 },
            { type: "lost", wasAttack: true, round: 21 },
            { type: "lost", wasAttack: false, round: 22 },
            { type: "lost", wasAttack: false, round: 23 },
            { type: "defused", wasAttack: false, round: 24 },
            { type: "lost", wasAttack: true, round: 25 },
            { type: "lost", wasAttack: false, round: 26 },
          ],
        },
        {
          players: [
            {
              name: "Test",
              fullName: "Testg#ABC",
              playerId: 0,
              isAlive: true,
              agentInternal: "Wushu",
              locked: false,
              isObserved: false,
              armorName: "Heavy",
              money: 2100,
              moneySpent: 2900,
              highestWeapon: "Vandal",
              isCaptain: false,
              currUltPoints: 2,
              maxUltPoints: 7,
              ultReady: false,
              hasSpike: false,
              scoreboardAvailable: true,
              auxiliaryAvailable: {
                health: true,
                abilities: true,
                scoreboard: true,
              },
              kills: 0,
              deaths: 0,
              assists: 0,
              killsThisRound: 0,
              deathsThisRound: 0,
              killedPlayerNames: [],
              health: 100,
              abilities: {
                grenade: 1,
                ability1: 1,
                ability2: 0,
              },
              iconNameSuffix: "",
            },
            {
              name: "Test",
              fullName: "Testg#ABC",
              playerId: 0,
              isAlive: true,
              agentInternal: "Smonk",
              locked: false,
              isObserved: false,
              armorName: "Heavy",
              money: 2100,
              moneySpent: 2900,
              highestWeapon: "Vandal",
              isCaptain: false,
              currUltPoints: 2,
              maxUltPoints: 7,
              ultReady: false,
              hasSpike: false,
              scoreboardAvailable: true,
              auxiliaryAvailable: {
                health: true,
                abilities: true,
                scoreboard: true,
              },
              kills: 0,
              deaths: 0,
              assists: 0,
              killsThisRound: 0,
              deathsThisRound: 0,
              killedPlayerNames: [],
              health: 100,
              abilities: {
                grenade: 1,
                ability1: 1,
                ability2: 0,
              },
              iconNameSuffix: "",
            },
            {
              name: "Test",
              fullName: "Testg#ABC",
              playerId: 0,
              isAlive: true,
              agentInternal: "Wushu",
              locked: false,
              isObserved: false,
              armorName: "Heavy",
              money: 2100,
              moneySpent: 2900,
              highestWeapon: "Vandal",
              isCaptain: false,
              currUltPoints: 2,
              maxUltPoints: 7,
              ultReady: false,
              hasSpike: false,
              scoreboardAvailable: true,
              auxiliaryAvailable: {
                health: true,
                abilities: true,
                scoreboard: true,
              },
              kills: 0,
              deaths: 0,
              assists: 0,
              killsThisRound: 0,
              deathsThisRound: 0,
              killedPlayerNames: [],
              health: 100,
              abilities: {
                grenade: 1,
                ability1: 1,
                ability2: 0,
              },
              iconNameSuffix: "",
            },
            {
              name: "Test",
              fullName: "Testg#ABC",
              playerId: 0,
              isAlive: true,
              agentInternal: "Wushu",
              locked: false,
              isObserved: false,
              armorName: "Heavy",
              money: 2100,
              moneySpent: 2900,
              highestWeapon: "Vandal",
              isCaptain: false,
              currUltPoints: 2,
              maxUltPoints: 7,
              ultReady: false,
              hasSpike: false,
              scoreboardAvailable: true,
              auxiliaryAvailable: {
                health: true,
                abilities: true,
                scoreboard: true,
              },
              kills: 0,
              deaths: 0,
              assists: 0,
              killsThisRound: 0,
              deathsThisRound: 0,
              killedPlayerNames: [],
              health: 100,
              abilities: {
                grenade: 1,
                ability1: 1,
                ability2: 0,
              },
              iconNameSuffix: "",
            },
            {
              name: "Test",
              fullName: "Testg#ABC",
              playerId: 0,
              isAlive: true,
              agentInternal: "Wushu",
              locked: false,
              isObserved: false,
              armorName: "Heavy",
              money: 2100,
              moneySpent: 2900,
              highestWeapon: "Vandal",
              isCaptain: false,
              currUltPoints: 2,
              maxUltPoints: 7,
              ultReady: false,
              hasSpike: false,
              scoreboardAvailable: true,
              auxiliaryAvailable: {
                health: true,
                abilities: true,
                scoreboard: true,
              },
              kills: 0,
              deaths: 0,
              assists: 0,
              killsThisRound: 0,
              deathsThisRound: 0,
              killedPlayerNames: [],
              health: 100,
              abilities: {
                grenade: 1,
                ability1: 1,
                ability2: 0,
              },
              iconNameSuffix: "",
            },
          ],
          teamName: "The Zoologists",
          teamUrl: "assets/misc/icon.webp",
          teamTricode: "ZOO",
          spentThisRound: 1000,
          isAttacking: true,
          roundsWon: 5,
          roundRecord: [
            { type: "lost", wasAttack: false, round: 1 },
            { type: "defused", wasAttack: false, round: 2 },
            { type: "lost", wasAttack: false, round: 3 },
            { type: "lost", wasAttack: false, round: 4 },
            { type: "kills", wasAttack: false, round: 5 },
            { type: "lost", wasAttack: false, round: 6 },
            { type: "detonated", wasAttack: false, round: 7 },
            { type: "lost", wasAttack: false, round: 8 },
            { type: "kills", wasAttack: false, round: 9 },
            { type: "timeout", wasAttack: false, round: 10 },
            { type: "lost", wasAttack: false, round: 11 },
            { type: "defused", wasAttack: false, round: 12 },
            { type: "lost", wasAttack: true, round: 13 },
            { type: "lost", wasAttack: true, round: 14 },
            { type: "kills", wasAttack: true, round: 15 },
            { type: "lost", wasAttack: true, round: 16 },
            { type: "detonated", wasAttack: true, round: 17 },
            { type: "lost", wasAttack: true, round: 18 },
            { type: "kills", wasAttack: true, round: 19 },
            { type: "timeout", wasAttack: true, round: 20 },
            { type: "lost", wasAttack: true, round: 21 },
            { type: "kills", wasAttack: true, round: 22 },
            { type: "lost", wasAttack: true, round: 23 },
            { type: "lost", wasAttack: true, round: 24 },
            { type: "kills", wasAttack: false, round: 25 },
            { type: "kills", wasAttack: true, round: 26 },
          ],
        },
      ],
    };
    this.dataModel.match.set(match);
  }

  ngOnDestroy(): void {
    this.stopAgentSelectTimer();
  }

  simulateAgentSelectStartTime() {
    this.stopAgentSelectTimer();

    const timerStart = performance.now();
    this.dataModel.match.update((v) => {
      const ret = v;
      ret.agentSelectStartTime = 0;
      return ret;
    });

    const tick = () => {
      const elapsedMs = performance.now() - timerStart;
      const clampedElapsedMs = Math.min(elapsedMs, 95_000);

      this.dataModel.match.update((v) => {
        const ret = v;
        ret.agentSelectStartTime = clampedElapsedMs;
        return ret;
      });

      if (clampedElapsedMs >= 95_000) {
        this.stopAgentSelectTimer();
        return;
      }

      this.agentSelectTimer = requestAnimationFrame(tick);
    };

    this.agentSelectTimer = requestAnimationFrame(tick);
  }

  private stopAgentSelectTimer() {
    if (this.agentSelectTimer !== undefined) {
      cancelAnimationFrame(this.agentSelectTimer);
      this.agentSelectTimer = undefined;
    }
  }

  lockAgent(teamIndex: number, playerIndex: number) {
    this.dataModel.match.update((v) => {
      const ret = v;
      const player = ret.teams[teamIndex].players[playerIndex];
      player.locked = true;
      return ret;
    });
  }

  unlockAgent(teamIndex: number, playerIndex: number) {
    this.dataModel.match.update((v) => {
      const ret = v;
      const player = ret.teams[teamIndex].players[playerIndex];
      player.locked = false;
      return ret;
    });
  }

  agentList = [
    "AggroBot",
    "BountyHunter",
    "Breach",
    "Cable",
    "Cashew",
    "Clay",
    "Deadeye",
    "Grenadier",
    "Guide",
    "Gumshoe",
    "Hunter",
    "Iris",
    "Killjoy",
    "Mage",
    "Nox",
    "Pandemic",
    "Paprika",
    "Phoenix",
    "Rift",
    "Sarge",
    "Sequoia",
    "Smonk",
    "Sprinter",
    "Stealth",
    "Terra",
    "Thorne",
    "Vampire",
    "Wraith",
    "Wushu",
  ];
  changeAgent(teamIndex: number, playerIndex: number) {
    this.dataModel.match.update((v) => {
      const ret = v;
      const player = ret.teams[teamIndex].players[playerIndex];
      player.agentInternal =
        this.agentList[
          (this.agentList.findIndex((e) => e === player.agentInternal) + 1) % this.agentList.length
        ];
      return ret;
    });
  }
}
